package org.videolan.libvlc.interfaces;

public interface IComponentFactory {

}
