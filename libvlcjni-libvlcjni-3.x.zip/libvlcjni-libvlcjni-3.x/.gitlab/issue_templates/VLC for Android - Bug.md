<!--- Provide a general summary of the issue in the Title above -->

## Description

<!--- Describe your bug in detail -->

#### Expected behavior

#### Actual behavior

#### Steps to reproduce

1.
2.
3.

#### Screenshot / video

<!--Add a screenshot or screencast when applicable-->
<!--To take a screenshot, see https://support.google.com/android/answer/9075928?hl=en-->


## Context

#### App version

<!--You can find it in the About screen of the app-->

#### Android version

#### Device model

#### App mode

<!--Remove the useless modes-->
**Smartphone**

**TV**

**Auto**