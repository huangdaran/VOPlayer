<!--- Provide a general summary of the request in the Title above -->

## Description

<!--- Describe your request in detail -->

#### Expected behavior


#### Screenshot / video

<!--Add a screenshot or screencast when applicable-->
<!--To take a screenshot, see https://support.google.com/android/answer/9075928?hl=en-->

#### App mode

<!--Remove the useless modes-->

**Smartphone**

**TV**

**Auto**